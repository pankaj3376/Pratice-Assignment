﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace List_CRUD_16_05_2023_.Models
{
    /*internal class Employee
    {
    }*/
    // Models/Person.cs
    public class Person
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public int Age { get; set; }
    }

}
