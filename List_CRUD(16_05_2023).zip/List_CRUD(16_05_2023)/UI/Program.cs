﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using List_CRUD_16_05_2023_.Models;
using System.Xml.Linq;
using List_CRUD_16_05_2023_.Services;

namespace List_CRUD_16_05_2023_.UI
{

    /*internal class Program
    {
    }*/

    // UI/Program.cs

    public class Program
    {
        private static PersonService personService = new PersonService();

        static void Main(string[] args)
        {
            while (true)
            {
                Console.WriteLine("1. Create person");
                Console.WriteLine("2. Read all persons");
                Console.WriteLine("3. Read person by ID");
                Console.WriteLine("4. Update person");
                Console.WriteLine("5. Delete person");
                Console.WriteLine("6. Exit");
                Console.WriteLine("Enter your choice:");

                int choice = Convert.ToInt32(Console.ReadLine());

                switch (choice)
                {
                    case 1:
                        CreatePerson();
                        break;
                    case 2:
                        ReadAllPersons();
                        break;
                    case 3:
                        ReadPersonById();
                        break;
                    case 4:
                        UpdatePerson();
                        break;
                    case 5:
                        DeletePerson();
                        break;
                    case 6:
                        Environment.Exit(0);
                        break;
                    default:
                        Console.WriteLine("Invalid choice!");
                        break;
                }
            }
        }

        private static void CreatePerson()
        {
            Console.WriteLine("Enter person ID:");
            int id = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Enter person name:\n");
                string name = Console.ReadLine();
            Console.WriteLine("Enter person age:");
            int age = Convert.ToInt32(Console.ReadLine());

            Person person = new Person { Id = id, Name = name, Age = age };
            personService.Create(person);

            Console.WriteLine("Person created successfully!");
        }

        private static void ReadAllPersons()
        {
            var persons = personService.ReadAll();

            if (persons.Count == 0)
            {
                Console.WriteLine("No persons found!");
            }
            else
            {
                foreach (var person in persons)
                {
                    Console.WriteLine($"ID: {person.Id}, Name: {person.Name}, Age: {person.Age}");
                }
            }
        }

        private static void ReadPersonById()
        {
            Console.WriteLine("Enter person ID:");
            int id = Convert.ToInt32(Console.ReadLine());

            Person person = personService.ReadById(id);

            if (person != null)
            {
                Console.WriteLine($"ID: {person.Id}, Name: {person.Name}, Age: {person.Age}");
            }
            else
            {
                Console.WriteLine("Person not found!");
            }
        }

        private static void UpdatePerson()
        {
            Console.WriteLine("Enter person ID:");
            int id = Convert.ToInt32(Console.ReadLine());

            Person existingPerson = personService.ReadById(id);

            if (existingPerson != null)
            {
                Console.WriteLine("Enter updated person name:");
                string name = Console.ReadLine();

                Console.WriteLine("Enter updated person age:");
                int age = Convert.ToInt32(Console.ReadLine());

                Person updatedPerson = new Person { Id = id, Name = name, Age = age };
                personService.Update(updatedPerson);

                Console.WriteLine("Person updated successfully!");
            }
            else
            {
                Console.WriteLine("Person not found!");
            }
        }

        private static void DeletePerson()
        {
            Console.WriteLine("Enter person ID:");
            int id = Convert.ToInt32(Console.ReadLine());

            personService.Delete(id);

            Console.WriteLine("Person deleted successfully!");
        }

    }
}