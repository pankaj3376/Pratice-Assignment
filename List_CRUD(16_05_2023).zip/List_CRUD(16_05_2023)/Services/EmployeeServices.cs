﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using List_CRUD_16_05_2023_.Models;

namespace List_CRUD_16_05_2023_.Services
{
    
    /*internal class EmployeeServices
    {
    }*/

    // Services/PersonService.cs
    

    public class PersonService
    {
        private List<Person> persons;

        public PersonService()
        {
            persons = new List<Person>();
        }

        public void Create(Person person)
        {
            persons.Add(person);
        }

        public List<Person> ReadAll()
        {
            return persons;
        }

        public Person ReadById(int id)
        {
            return persons.Find(p => p.Id == id);
        }

        public void Update(Person updatedPerson)
        {
            Person person = persons.Find(p => p.Id == updatedPerson.Id);
            if (person != null)
            {
                person.Name = updatedPerson.Name;
                person.Age = updatedPerson.Age;
            }
            else
            {
                Console.WriteLine("Person not found!");
            }
        }

        public void Delete(int id)
        {
            Person person = persons.Find(p => p.Id == id);
            if (person != null)
            {
                persons.Remove(person);
            }
            else
            {
                Console.WriteLine("Person not found!");
            }
        }
    }

}
